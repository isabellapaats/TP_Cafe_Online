const bebidas ={
    name:"Expresso",
    image: "https://i2.wp.com/www.coffeeiq.co/wp-content/uploads/2019/05/caf%C3%A9-Espresso-shot.png?fit=600%2C450&ssl=1",
    description:"Verdadero Sabor del Café Espresso Italiano en su Hogar u Oficina",
    price:"$120"

}

export {
    bebidas
}