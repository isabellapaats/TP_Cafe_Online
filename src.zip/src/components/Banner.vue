<template>
<div id="main-banner">
  <a href="https://listado.mercadolibre.com.ar/tablet#D[A:tablet]" target="_blank">
  <h3> Nueva Tablet Samsung Galaxy</h3>
  <img class="img-banner" src="https://http2.mlstatic.com/D_NQ_NP_992019-MLA44207852270_112020-V.webp">
  <p id ="descripcion">Tab A7 SM-T500 10.4" 64GB gold con 3GB de memoria RAM</p>
  <p> ¡COMPRAR!</p>
  </a>

</div>
</template>

<script>
export default {
  name: "Banner"
}
</script>

<style scoped>
@import "../assets/css/Banner.css";

</style>