

<script>
export default {
  name: "Footer"
}
</script>

<style scoped>

</style>